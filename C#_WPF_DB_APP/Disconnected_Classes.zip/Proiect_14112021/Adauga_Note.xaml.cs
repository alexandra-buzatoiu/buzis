﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Adauga_Note.xaml
    /// </summary>
    public partial class Adauga_Note : Window
    {
        static string connectionString = "Server=.;Database=catalog;Trusted_Connection=true";
        SqlConnection connection = new SqlConnection(connectionString);
        DataTable DS = new DataTable();
        SqlDataAdapter DA = new SqlDataAdapter();


        public Adauga_Note()
        {
            InitializeComponent();
            UpdateItems();
        }


        private void UpdateItems()
        {
            try
            {

                using (SqlConnection con = new SqlConnection("Server=.;Database=catalog;Trusted_Connection=true"))
                {
                    con.Open();
                    SqlDataAdapter ProjectTableTableAdapter = new SqlDataAdapter("SELECT Nume_Materie FROM Materii", con);
                    DataSet ds = new DataSet();
                    ProjectTableTableAdapter.Fill(ds, "Nume_Materie");

                    ComboBox_Materie.ItemsSource = ds.Tables["Nume_Materie"].DefaultView;
                    ComboBox_Materie.DisplayMemberPath = "Nume_Materie";
                    ComboBox_Materie.SelectedValue = "Id_Materii";

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Button_Inapoi_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }

        private void Button_StergeNota_Click(object sender, RoutedEventArgs e)
        {

            SqlCommand selectCMDgetid;
            SqlCommand selectCMDidmaterie;
            SqlCommand selectCMD;
            //SqlDataAdapter DA = new SqlDataAdapter();
            selectCMDgetid = new SqlCommand(string.Format
                 ("SELECT Id_Elev FROM Elevi WHERE Nume_Elev = @Nume AND Prenume_Elev = @Prenume"),
                 connection);
            selectCMDgetid.Parameters.AddWithValue("@Nume", TextBox_Nume.Text);
            selectCMDgetid.Parameters.AddWithValue("@Prenume", TextBox_Prenume.Text);
            connection.Open();
            int idElev = Convert.ToInt32(selectCMDgetid.ExecuteScalar());
            connection.Close();

            //DA.SelectCommand = selectCMDgetid;
            //connection.Open();
            //DS.Clear();
            //DA.Fill(DS);
            //connection.Close();


            selectCMDidmaterie = new SqlCommand(string.Format
                 ("select Id_Materie from Materii where Nume_Materie = @Materie"),
                 connection);
            selectCMDidmaterie.Parameters.AddWithValue("@Materie", ComboBox_Materie.Text);

            DA.SelectCommand = selectCMDidmaterie;
            connection.Open();
            int idMaterie = Convert.ToInt32(selectCMDidmaterie.ExecuteScalar());
            DS.Clear();
            DA.Fill(DS);
            connection.Close();




            selectCMD = new SqlCommand(string.Format
                 ("DELETE FROM Catalog_Note WHERE Id_Elev=@Id_Elev AND Id_Materie=@Id_Materie AND Nota=@Nota AND Data=@Data"),
                 connection);

            selectCMD.Parameters.AddWithValue("@Id_Elev", idElev);
            selectCMD.Parameters.AddWithValue("@Id_Materie", idMaterie);
            selectCMD.Parameters.AddWithValue("@Nota", TextBox_Nota.Text);
            selectCMD.Parameters.AddWithValue("@Data", TextBox_Data.Text);

            connection.Open();
            //DA.SelectCommand = selectCMD;
            // int count_smth = Convert.ToInt32(selectCMD.ExecuteScalar());
            selectCMD.ExecuteNonQuery();
            connection.Close();

            MessageBox.Show("Nota a fost stearsa din catalog");


        }

        private void Button_AdaugareNota_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand selectCMDgetid;
            SqlCommand selectCMDidmaterie;
            SqlCommand selectCMD;
            //SqlDataAdapter DA = new SqlDataAdapter();
            selectCMDgetid = new SqlCommand(string.Format
                 ("SELECT Id_Elev FROM Elevi WHERE Nume_Elev = @Nume AND Prenume_Elev = @Prenume"),
                 connection);
            selectCMDgetid.Parameters.AddWithValue("@Nume", TextBox_Nume.Text);
            selectCMDgetid.Parameters.AddWithValue("@Prenume", TextBox_Prenume.Text);
            connection.Open();
            int idElev = Convert.ToInt32(selectCMDgetid.ExecuteScalar());
            connection.Close();

            //DA.SelectCommand = selectCMDgetid;
            //connection.Open();
            //DS.Clear();
            //DA.Fill(DS);
            //connection.Close();


            selectCMDidmaterie  = new SqlCommand(string.Format
                 ("select Id_Materie from Materii where Nume_Materie = @Materie"),
                 connection);
            selectCMDidmaterie.Parameters.AddWithValue("@Materie", ComboBox_Materie.Text);
            
            DA.SelectCommand = selectCMDidmaterie;
            connection.Open();
            int idMaterie = Convert.ToInt32(selectCMDidmaterie.ExecuteScalar());
            DS.Clear();
            DA.Fill(DS);
            connection.Close();




            selectCMD = new SqlCommand(string.Format
                 ("INSERT INTO Catalog_Note (Id_Elev, Id_Materie, Nota, Data) VALUES(@Id_Elev, @Id_Materie, @Nota, @Data); "),
                 connection);

            selectCMD.Parameters.AddWithValue("@Id_Elev", idElev);
            selectCMD.Parameters.AddWithValue("@Id_Materie", idMaterie);
            selectCMD.Parameters.AddWithValue("@Nota", TextBox_Nota.Text);
            selectCMD.Parameters.AddWithValue("@Data", TextBox_Data.Text);

            connection.Open();
            //DA.SelectCommand = selectCMD;
           // int count_smth = Convert.ToInt32(selectCMD.ExecuteScalar());
            selectCMD.ExecuteNonQuery();
            connection.Close();

            MessageBox.Show("Nota dvs. a fost adaugata");
        }
    }
}
