#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#define LINE_SIZE 257
#define ELEMENT_SIZE 100
#define FILE_NAME 150
#define PATH_SIZE 150

typedef struct celula {
	char* key;
	char* val;
	struct celula* next;
} Cell, * Hash;

Cell* createHashElement(char* key, char* val)
{
	Cell* aux;

	aux = (Cell*)calloc(1, sizeof(Cell));
	if (!aux)
		return NULL;
	aux->key = (char*)calloc(1, ELEMENT_SIZE);
	if (!aux->key)
		return NULL;
	aux->val = (char*)calloc(1, ELEMENT_SIZE);
	if (!aux->val)
		return NULL;
	memcpy(aux->key, key, strlen(key));
	memcpy(aux->val, val, strlen(val));
	aux->next = NULL;
	return aux;
}
void freeHashMapElement(Cell* cell)
{
	free(cell->key);
	free(cell->val);
	free(cell);
}
int addHashElement(char* key, char* val, Hash* h)
{
	Hash aux;

	aux = createHashElement(key, val);
	if (!aux)
		return 0;
	aux->next = *h;
	*h = aux;
	return 1;
}
int removeHashElement(char* key, Hash* h)
{
	Hash ant, p;

	for (p = *h, ant = NULL; p != NULL; ant = p, p = p->next)
		if (strcmp(p->key, key) == 0)
			break;
	if (p == NULL)
		return 0;
	if (ant == NULL)
		*h = p->next;
	else
		ant->next = p->next;
	freeHashMapElement(p);
	return 1;
}

void freeHashMap(Hash* h)
{
	Hash aux;

	while (*h) {
		aux = *h;
		*h = (*h)->next;
		freeHashMapElement(aux);
	}

}
char* getHashValue(char* key, Hash h)
{
	Hash aux;

	for (aux = h; aux != NULL; aux = aux->next) {
		if (strcmp(aux->key, key) == 0)
			return aux->val;
	}
	return NULL;
}

