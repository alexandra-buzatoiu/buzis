#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "so_stdio.h"
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#define BUFSIZE 4096
typedef struct _so_file {
	int fd; /*file descriptor*/
	long seek; /*pozitia cursurului*/
	int eof;
	int error;
	int pid;
	int char_now;
	int bytes_in_buffer;/*numarul de bytes din buffer*/
	char last_operation_done;
	char* buff;/*buffer*/

} SO_FILE;

SO_FILE* allocStructure(int fd)
{
	SO_FILE* so_file;

	so_file = calloc(1, sizeof(SO_FILE));
	if (!so_file)
		return NULL;
	so_file->buff = calloc(BUFSIZE, sizeof(char));
	if (!so_file->buff)
		return NULL;
	so_file->fd = fd;
	so_file->last_operation_done = '-';
	so_file->eof = 0;
	so_file->error = 0;
	so_file->pid = 0;
	so_file->char_now = 0;
	so_file->bytes_in_buffer = 0;
	so_file->seek = 0;

	return so_file;
}
void freeStructure(SO_FILE* stream)
{
	free(stream->buff);
	free(stream);
}
SO_FILE* so_fopen(const char* pathname, const char* mode)
{
	int fd = -1;
	SO_FILE* so_file = NULL;


	/*deschidem fisierul intr-unul din cele 3 moduri posibile
	+ toate variantele cu +*/
	if (*mode == 'r') {
		if (strcmp(mode, "r+") == 0)
			fd = open(pathname, O_RDWR, 0644);
		else
			fd = open(pathname, O_RDONLY, 0644);
	}

	if (*mode == 'w') {
		if (strcmp(mode, "w+") == 0)
			fd = open(pathname, O_WRONLY | O_TRUNC | O_CREAT, 0644);
		else
			fd = open(pathname, O_RDWR | O_TRUNC | O_CREAT, 0644);
	}

	if (*mode == 'a') {
		if (strcmp(mode, "a+") == 0)
			fd = open(pathname, O_APPEND | O_RDWR | O_CREAT, 0644);
		else
			fd = open(pathname, O_APPEND | O_WRONLY | O_CREAT, 0644);
	}
	if (fd == -1)
		so_file = NULL;
	else
		so_file = allocStructure(fd);
	return so_file;
}

int so_fileno(SO_FILE* stream)
{
	return stream->fd;
}
int so_fflush(SO_FILE* stream)
{
	int wb;
	int written = 0;
	/*incercam sa scriem toti bytes din buffer in fisier*/
	wb = write(stream->fd, stream->buff + written, stream->bytes_in_buffer - written);
	if (wb == -1) {
		stream->error = 1;
		return SO_EOF;
	}
	written += wb;
	/*incercam sa scriem tot, in bucla*/
	while (written != stream->bytes_in_buffer) {
		wb = write(stream->fd, stream->buff + written,
			stream->bytes_in_buffer - written);
		if (wb == -1) {
			stream->error = 1;
			return SO_EOF;
		}
		written += wb;
	}
	stream->bytes_in_buffer = 0;
	memset(stream->buff, 0, BUFSIZE);
	return 0;
}

int so_fclose(SO_FILE* stream)
{
	int closeError, bRet;
	/*incercam sa facem fflush pe buffer
	daca ultima operatie a fost de scriere*/
	if (stream->last_operation_done == 'w') {
		bRet = so_fflush(stream);
		if (bRet == -1) {
			/*eliberam memorie + return*/
			close(stream->fd);
			freeStructure(stream);
			return SO_EOF;
		}
	}
	/*inchidem fisierul si setam eroarea*/
	closeError = close(stream->fd);
	if (closeError < 0) {
		/*eliberam memorie + return eroare */
		stream->error = 1;
		freeStructure(stream);
		return SO_EOF;
	}
	/*daca nu apar erori doar eliberam structura*/
	freeStructure(stream);
	return 0;
}

long so_ftell(SO_FILE* stream)
{
	return stream->seek;
}

int so_ferror(SO_FILE* stream)
{
	return stream->error;
}

int so_feof(SO_FILE* stream)
{
	return stream->eof;
}


int so_fseek(SO_FILE* stream, long offset, int whence)
{
	int succes = 0;
	/*ultima op a fost citire*/
	if (stream->last_operation_done == 'r') {
		stream->bytes_in_buffer = 0;
		stream->char_now = 0;
		memset(stream->buff, 0, BUFSIZE);
	}
	/*ultima op a fost scroere*/
	if (stream->last_operation_done == 'w')
		so_fflush(stream);
	/*incercam sa mutam cursurul si sa salvam nr bytes*/
	succes = lseek(stream->fd, offset, whence);
	if (succes != -1) {
		stream->seek += succes;
		return 0;
	}
	return SO_EOF;
}


int so_fgetc(SO_FILE* stream)
{
	
	/*citim din fisier in buffer o singura data apoi returnam caractere din buffer
	cat timp nu am ajuns la finalul bufferului
	cand ajungem la finalul bufferului, resetam counterul de caractere, 
	numerul de bytes in buffer il punem pe 0 si facem memset 0 pe buffer*/
	unsigned char c = -1;
	int bytesRead;
	/*verificam daca am ajuns la eof*/
	if (stream->eof == 1)
		return SO_EOF;
	/*verificam daca bufferul e gol*/
	if (stream->bytes_in_buffer == 0) {
		bytesRead = read(stream->fd, stream->buff, BUFSIZE);
		/*setam eof*/
		if (bytesRead == 0) {
			stream->eof = 1;
			return SO_EOF;
		}
		/*eroare + return*/
		if (bytesRead == -1) {
			stream->error = 1;
			return SO_EOF;
		}
		/*save numer of read bytes*/
		c = (unsigned char)stream->buff[stream->char_now];
		stream->bytes_in_buffer = bytesRead;
		stream->char_now++;
	}
	else {
		/*daca actualul caracter e ultimul*/
		if (stream->char_now == stream->bytes_in_buffer - 1) {
			c = (unsigned char)stream->buff[stream->char_now];
			/*curatam contextul*/
			memset(stream->buff, 0, BUFSIZE);
			stream->bytes_in_buffer = 0;
			stream->char_now = 0;
			
			
		}
		else {
			c = (unsigned char)stream->buff[stream->char_now];
			stream->char_now++;
		}
	}
	return  c;
}
size_t so_fread(void* ptr, size_t size, size_t nmemb, SO_FILE* stream)
{
	int readCharacter;
	size_t nr_elem = 0;

	for (int i = 0; i < nmemb; i++) {
		for (int j = 0; j < size; j++) {
			/*citim un caracter*/
			readCharacter = so_fgetc(stream);
			if (readCharacter != SO_EOF) {
				/*punem caracterul si mutam cursorul*/
				(*(char*)(ptr + i * size + j)) = readCharacter;
				stream->seek++;
			}
			else {
				stream->error = 1;
				/*memoram ca last op a fost citire + return*/
				stream->last_operation_done = 'r';
				return nr_elem;
			}
		}
		nr_elem += 1;
	}
	/*memoram ca last op a fost citire + return*/
	stream->last_operation_done = 'r';
	return nr_elem;
}
int so_fputc(int c, SO_FILE* stream)
{
	int bRet;
	/*verificam daca avem loc sau nu in buffer*/
	if (stream->bytes_in_buffer != BUFSIZE) {
		/*adaugam char in buffer*/
		stream->char_now = 0;
		stream->seek++;
		(*(char*)(stream->buff + stream->bytes_in_buffer)) = c;
		stream->bytes_in_buffer += 1;
		
	}
	else {
		/*flush buffer cand atingem BUFSIZE*/
		stream->bytes_in_buffer = BUFSIZE;
		bRet = so_fflush(stream);
		if (bRet != -1) {
			stream->seek++;
			stream->bytes_in_buffer += 1;
			(*(char*)(stream->buff)) = c;
			
		}
		stream->char_now = 0;
	}
	/*retinem ca ultima op a fost w*/
	stream->last_operation_done = 'w';
	return c;
}
size_t so_fwrite(const void* ptr, size_t size, size_t nmemb, SO_FILE* stream)
{
	int i, j;
	unsigned char ch;
	int bRet;
	int nr_elem = 0;

	for (i = 0; i < nmemb; i++) {
		for (j = 0; j < size; j++) {
			ch = (unsigned char)(*(char*)(ptr + i * size + j));
			bRet = so_fputc(ch, stream);
			/*setam eroarea*/
			if (bRet < 0) {
				stream->error = 1;
				return SO_EOF;
			}
		}
		nr_elem++;
	}
	/*retinem ultima operatie*/
	stream->last_operation_done = 'w';
	return nr_elem;
}



SO_FILE* so_popen(const char* command, const char* type)
{
	SO_FILE* so_file = NULL;
	
	return so_file;
}
int so_pclose(SO_FILE* stream)
{
	int bRet;
	
	return bRet;
}
