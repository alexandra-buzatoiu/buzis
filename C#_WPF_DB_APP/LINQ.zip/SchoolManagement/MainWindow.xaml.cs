﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        catalogDataContext cd = new catalogDataContext();
        //static string connectionString = "Server=.;Database=catalog;Trusted_Connection=true";
        //SqlConnection connection = new SqlConnection(connectionString);
        // <PasswordBox x:Name="TextBox_Password" HorizontalAlignment="Left" Height="23" Margin="217,261,0,0" TextWrapping="Wrap" VerticalAlignment="Top" Width="304" Background="#FFF9FA72"/>
        public MainWindow()
        {
            InitializeComponent();
            TextBox_Password.PasswordChar = '*';
            //TextBox_Password.MaxLength = 15;

            //connection.Open();

            //connection.Close();



        }

        private void Button_LogIn_Click(object sender, RoutedEventArgs e)
        {

            //SqlConnection sqlCon = new SqlConnection();
            //sqlCon.ConnectionString = "Server=.;Database=catalog;Trusted_Connection=true";

            try
            {
                //if (sqlCon.State == System.Data.ConnectionState.Closed)
                //    sqlCon.Open();
                //String query = "SELECT COUNT(1) FROM Profesori WHERE username=@Username AND password=@Password";
                //SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.CommandType = System.Data.CommandType.Text;
                //sqlCmd.Parameters.AddWithValue("@Username", TextBox_username.Text);
                //sqlCmd.Parameters.AddWithValue("@Password", TextBox_Password.Text);
                string user = TextBox_username.Text;
                string pass = TextBox_Password.Password;
                var result = from t in cd.Profesoris
                             where t.username == user && t.password == pass
                             select t;

                //int count = Convert.ToInt32(sqlCmd.ExecuteScalar());
                if (result.Count() == 1)
                {
                    Possible_Actions ob = new Possible_Actions();
                    ob.Show();
                    this.Close();
                }                               // cu acest if deschidem urm fereastra
                else
                {
                    System.Windows.MessageBox.Show("Nume de utilizator sau parola incorecta!");
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message);
            }
            //finally
            //{
            //    sqlCon.Close();
            //}

        }

        private void Button_SignUp_Click(object sender, RoutedEventArgs e)
        {
            RegisterWindow registr = new RegisterWindow();
            registr.Show();
            this.Close();
        }
    }
}
