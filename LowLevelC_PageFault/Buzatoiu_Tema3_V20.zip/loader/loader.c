#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include "exec_parser.h"


static so_exec_t* exec;
static struct sigaction old_action;
static int pageSize;
int fd;



static void pagefault_handler(int signum, siginfo_t* info, void* context)
{
	int alignMem; /*indexul paginii care genereaza fault*/
	char* pageFault_addr;/*adresa la care s-a produs page fault*/
	int nrPages; /*nr pagini*/
	unsigned int offset;/*offset in fisier*/
	unsigned int permisions;/*permisiuni*/
	int bRet;/*pentru output si erori*/
	int mem_size;/*dimensiunea seg pt cand lucram cu memoria*/
	int file_size;/*dimensiunea seg pt cand lucram cu fisier*/
	char* seg_addr;/*adresa de start a seg*/
	void* pr; /*pentru reurnul lui mmap*/



	/*verificam daca primim semnalul SIGSEGV */
	if (signum != SIGSEGV) {
		old_action.sa_sigaction(signum, info, context);
		return;
	}
	/*adresa la care s-a produs fault*/
	pageFault_addr = (char*)info->si_addr;

	/*iteram printre segmentele executabilului*/
	for (int i = 0; i < exec->segments_no; i++) {
		/*setam variabilele pentru seg de executabil curent*/
		mem_size = exec->segments[i].mem_size;
		offset = exec->segments[i].offset;
		file_size = exec->segments[i].file_size;
		permisions = exec->segments[i].perm;
		seg_addr = (char*)exec->segments[i].vaddr;
		/*calculam nr pg coresp*/
		nrPages = (int)(mem_size / pageSize) + 1;

		/*alocam spatiu pentru date
		in functie de nr pagini si dimensiunea paginii*/
		if (exec->segments[i].data == NULL)
			exec->segments[i].data = calloc(nrPages, pageSize);

		/*determinam indexul pg unde s-a generat SIGSEV
		aliniem mem cu asta!*/
		alignMem = (pageFault_addr - seg_addr) / pageSize;

		//mapam pagini daca adresa la care a aparut page fault 
		//se afla in segmentul curent 

		if (pageFault_addr >= seg_addr &&
			pageFault_addr < seg_addr + mem_size)
		{
			
		
			/*daca pagina nu e mapata*/
			if (((int*)exec->segments[i].data)[alignMem] == 0)
			{
				/*dam permisiuni paginii*/
				bRet = mprotect(pageFault_addr, pageSize, permisions);
	
				/*pagina e mapata complet folosind fisier*/
				pr = mmap(alignMem * pageSize + seg_addr,
					pageSize, permisions,
					MAP_PRIVATE | MAP_FIXED, fd,
					alignMem * pageSize + offset);

				((int*)exec->segments[i].data)[alignMem] = 1;
				//astfel marcam maparea
				return;

			}

			else //daca pg mapata -> handler default
			{
				old_action.sa_sigaction(signum, info, context);
				return;
			}
		}
	}
	/*default handler nu ne ocupam
	de situatia in care nu e in segmentul curent*/
	old_action.sa_sigaction(signum, info, context);
	return;
}

int so_init_loader(void)
{
	struct sigaction action;
	int bRet;
	pageSize = getpagesize();
	/*handler*/
	action.sa_sigaction = pagefault_handler;
	sigemptyset(&action.sa_mask);
	/*SIGSEGV*/
	sigaddset(&action.sa_mask, SIGSEGV);
	action.sa_flags = SA_SIGINFO;

	bRet = sigaction(SIGSEGV, &action, &old_action);
	//DIE(bRet < 0, "sigaction");
	return 0;
}

int so_execute(char* path, char* argv[])
{

	fd = open(path, O_RDONLY);
	if (fd < 0)
		return -1;
	exec = so_parse_exec(path);
	if (!exec)
		return -1;

	so_start_exec(exec, argv);

	return 0;
}
