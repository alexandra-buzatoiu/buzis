﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for RegisterWindow.xaml
    /// </summary>
    public partial class RegisterWindow : Window
    {
        catalogDataContext cd = new catalogDataContext();

        public RegisterWindow()
        {
            InitializeComponent();
        }


        private bool CheckExistingUsername(string user)
        {

            string username = TextBox_Username.Text;
            var result = from t in cd.Profesoris
                         where t.username == username
                         select t;
            if(result.Count() == 0)
            {
                return true;
            }

            
            return false;
        }


        private void Button_Back_To_LogIn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow menu = new MainWindow();
            menu.Show();
            this.Close();
        }

        private void Button_Register_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string username = TextBox_Username.Text;
                string pass = TextBox_Parola.Text;
                string nume = TextBox_Nume.Text;
                string pren = TextBox_Prenume.Text;
                var result1 = from t in cd.Profesoris
                             where t.Nume_Profesor == nume && t.Prenume_Profesor == pren
                             select t;
                if(result1.Count()!=1)
                {
                    MessageBox.Show("Nu se poate crea un cont in aplicatie pentru un profesor care nu apartine scolii!");
                }

                var result = (from t in cd.Profesoris
                              where t.Nume_Profesor == nume && t.Prenume_Profesor == pren
                              select t).SingleOrDefault();
               
                
                if (TextBox_Username.Text != "" && TextBox_Parola.Text != "" && TextBox_Nume.Text != "" && TextBox_Prenume.Text != ""  && CheckExistingUsername(TextBox_Username.Text))
                {
                   

                    result.username = username;
                    result.password = pass;
                    cd.SubmitChanges();
                    MessageBox.Show("V-ati inregistrat cu succes!");

                }
                else
                    MessageBox.Show("Inregistrarea a esuat! Aveti campuri goale sau username-ul exista deja.");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           

        }
    }

}
    

