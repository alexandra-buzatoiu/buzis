select * from Profesori
Delete from Profesori where Id_Profesor = 31