﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Meniu_Materii.xaml
    /// </summary>
    public partial class Meniu_Materii : Window
    {
        catalogDataContext cd = new catalogDataContext();



        public Meniu_Materii()
        {
            InitializeComponent();
            UpdateItems();
        }


        private void UpdateItems()
        {
            try
            {

                var result = (from t in cd.Materiis
                              select t.Nume_Materie).ToList();

                ComboBox_Materii.ItemsSource = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        private void Button_Inapoi_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }

        private void ComboBox_Materii_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          


            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            string materie = ComboBox_Materii.Text;

            var result = (from m in cd.Materiis
                         join mp in cd.Materii_Profesoris
                         on m.Id_Materie equals mp.Id_Materie
                         join p in cd.Profesoris
                         on mp.Id_Profesor equals p.Id_Profesor
                         let NumeCadruDidactic = p.Nume_Profesor + ' ' + p.Prenume_Profesor
                         where m.Nume_Materie == materie
                         select new { NumeCadruDidactic }).ToList();
            DataGrid_Profesori_Materii.ItemsSource = result;
   
        }
    }
}
