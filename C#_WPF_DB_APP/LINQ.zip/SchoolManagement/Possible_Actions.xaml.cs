﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Possible_Actions.xaml
    /// </summary>
    public partial class Possible_Actions : Window
    {
        public Possible_Actions()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow menu = new MainWindow();
            menu.Show();
            this.Close();
        }

        private void Button_Profesori_Click(object sender, RoutedEventArgs e)
        {
            Meniu_Profesori ob = new Meniu_Profesori();
            ob.Show();
            this.Close();
        }

        private void Button_Elevi_Click(object sender, RoutedEventArgs e)
        {
            Meniu_Elevi ob = new Meniu_Elevi();
            ob.Show();
            this.Close();
        }

        private void Button_Materii_Click(object sender, RoutedEventArgs e)
        {
            Meniu_Materii ob = new Meniu_Materii();
            ob.Show();
            this.Close();
        }

        private void Button_Clase_Click(object sender, RoutedEventArgs e)
        {
            Meniu_Clase ob = new Meniu_Clase();
            ob.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Adauga_Note ob = new Adauga_Note();
            ob.Show();
            this.Close();
        }
    }
}
