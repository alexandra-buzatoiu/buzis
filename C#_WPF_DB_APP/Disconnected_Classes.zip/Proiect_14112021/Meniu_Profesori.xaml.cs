﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Meniu_Profesori.xaml
    /// </summary>
    public partial class Meniu_Profesori : Window
    {

        static string connectionString = "Server=.;Database=catalog;Trusted_Connection=true";
        SqlConnection connection = new SqlConnection(connectionString);
        DataTable DS = new DataTable();
        SqlDataAdapter DA = new SqlDataAdapter();

        string currentTableName = "";

        public Meniu_Profesori()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }

        private void Button_Generare_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand selectCMD;
            selectCMD = new SqlCommand(string.Format
                 ("SELECT M.Nume_Materie, C.Nume_Clasa FROM Profesori AS P INNER JOIN Repartitie_Profesori_Clase_Materii AS RPCM ON P.Id_Profesor = RPCM.Id_Profesor INNER JOIN Materii AS M ON M.Id_Materie = RPCM.Id_Materie INNER JOIN Clase AS C ON C.Id_Clasa = RPCM.Id_Clasa WHERE P.Nume_Profesor = @Nume AND P.Prenume_Profesor = @Prenume"),
                 connection);

            selectCMD.Parameters.AddWithValue("@Nume", TextBox_NumeProf.Text);
            selectCMD.Parameters.AddWithValue("@Prenume", TextBox_PrenumeProf.Text);
            DA.SelectCommand = selectCMD;

            connection.Open();
            DS.Clear();
            DA.Fill(DS);
            DataGrid_Profesor.ItemsSource = DS.DefaultView;

            connection.Close();
        }

        private void DataGrid_Profesor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
