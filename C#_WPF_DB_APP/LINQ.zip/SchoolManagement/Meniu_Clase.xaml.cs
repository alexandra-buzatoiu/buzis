﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Meniu_Clase.xaml
    /// </summary>
    public partial class Meniu_Clase : Window
    {
        catalogDataContext cd = new catalogDataContext();

        static string connectionString = "Server=.;Database=catalog;Trusted_Connection=true";
        SqlConnection connection = new SqlConnection(connectionString);
        DataTable DS = new DataTable();
        SqlDataAdapter DA = new SqlDataAdapter();


        public Meniu_Clase()
        {
            InitializeComponent();
            UpdateItems();

        }


        private void UpdateItems()
        {
            try
            {
                ComboBox_Detalii_Clasa.Items.Clear();
                ComboBox_Clasa.SelectedItem = null;
                ComboBox_Detalii_Clasa.Items.Add("Componenta clasa");
                ComboBox_Detalii_Clasa.Items.Add("Incadrare clasa");

                var result = (from c in cd.Clases
                              select c.Nume_Clasa).ToList();
                ComboBox_Clasa.ItemsSource = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Button_Inapoi_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }

        private void DataGrid_Clasa_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ComboBox_Clasa_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //UpdateItems();
        }

      

        private void Button_Generare_Click(object sender, RoutedEventArgs e)
        {
            string clasa = ComboBox_Clasa.Text;

            if (ComboBox_Detalii_Clasa.Text == "Componenta clasa")
            {

                var result = (from c in cd.Clases
                              join el in cd.Elevis
                              on c.Id_Clasa equals el.Id_Clasa
                              where c.Nume_Clasa == clasa
                              select new { el.Nume_Elev, el.Prenume_Elev}).ToList();
                DataGrid_Clasa.ItemsSource = result;


            }

            else if(ComboBox_Detalii_Clasa.Text == "Incadrare clasa")
            {


                var result = (from c in cd.Clases
                             join rp in cd.Repartitie_Profesori_Clase_Materiis
                             on c.Id_Clasa equals rp.Id_Clasa
                             join p in cd.Profesoris
                             on rp.Id_Profesor equals p.Id_Profesor
                             join m in cd.Materiis
                             on rp.Id_Materie equals m.Id_Materie
                             let CadruDidactic = p.Nume_Profesor + ' ' + p.Prenume_Profesor
                             where c.Nume_Clasa == clasa
                             select new { m.Nume_Materie, CadruDidactic }).ToList();
                DataGrid_Clasa.ItemsSource = result;





            }


            //UpdateItems();

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //UpdateItems();
        }
    }
    
}
