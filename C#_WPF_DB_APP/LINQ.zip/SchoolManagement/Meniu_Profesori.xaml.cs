﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Meniu_Profesori.xaml
    /// </summary>
    public partial class Meniu_Profesori : Window
    {
        catalogDataContext cd = new catalogDataContext();



        public Meniu_Profesori()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }

        private void Button_Generare_Click(object sender, RoutedEventArgs e)
        {
            string Nume = TextBox_NumeProf.Text;
            string Prenume = TextBox_PrenumeProf.Text;


            var result = (from t in cd.Profesoris
                         join u in cd.Repartitie_Profesori_Clase_Materiis
                         on t.Id_Profesor equals u.Id_Profesor
                         join m in cd.Materiis
                         on u.Id_Materie equals m.Id_Materie
                         join v in cd.Clases
                         on u.Id_Clasa equals v.Id_Clasa
                         where t.Nume_Profesor == Nume && t.Prenume_Profesor == Prenume
                         select new { m.Nume_Materie, v.Nume_Clasa }).ToList();

            DataGrid_Profesor.ItemsSource = result;
        }

        private void DataGrid_Profesor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ButtonXML_Click(object sender, RoutedEventArgs e)
        {
            XmlTextReader xtr = new XmlTextReader("D:\\ATM\\ANUL_3\\Ap_BD\\Proiect2\\SchoolManagement\\profesor.xml");

            string nume_xml = "", prenume_xml = "";

            while (xtr.Read())
            {
                if (xtr.NodeType == XmlNodeType.Element && xtr.Name == "Nume")
                {
                    nume_xml = xtr.ReadElementContentAsString();
                }
                if (xtr.NodeType == XmlNodeType.Element && xtr.Name == "Prenume")
                {
                    prenume_xml = xtr.ReadElementContentAsString();
                }
     
                
            }

            SqlConnection sqlCon = new SqlConnection();
            sqlCon.ConnectionString = "Server=.;Database=catalog;Trusted_Connection=true";

            try
            {
                if (sqlCon.State == System.Data.ConnectionState.Closed)
                    sqlCon.Open();
                String query = "INSERT INTO Profesori (Nume_Profesor,Prenume_Profesor) VALUES (@Nume,@Prenume)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.CommandType = System.Data.CommandType.Text;
                sqlCmd.Parameters.AddWithValue("@Nume", nume_xml);
                sqlCmd.Parameters.AddWithValue("@Prenume", prenume_xml);


                if (nume_xml != "" && prenume_xml != "")
                {
                    int count = Convert.ToInt32(sqlCmd.ExecuteScalar()); 
                    MessageBox.Show("Profesorul a fost adaugat cu succes in baza de date prin import XML!");
                    MainWindow dashboard = new MainWindow();
                    dashboard.Show();
                    this.Close();
                }
                else
                    MessageBox.Show("Nu s-a putut adauga profesorul!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
