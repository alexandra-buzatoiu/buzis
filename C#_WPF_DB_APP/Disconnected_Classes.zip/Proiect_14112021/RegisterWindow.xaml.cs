﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for RegisterWindow.xaml
    /// </summary>
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }


        private bool CheckExistingUsername(string user)
        {
            var connection = new SqlConnection();
            connection.ConnectionString = "Server=.;Database=catalog;Trusted_Connection=true";
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();

            var cmd = connection.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = $"SELECT COUNT(*) as Nr FROM Profesori where username = '{user}'";

            DbDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                if (reader["Nr"].ToString() == "0")
                {
                    // connection.Close();
                    return true;
                }
                
            }

            // connection.Close();
           
            MessageBox.Show("Exista acest username in baza de date!");

            
            return false;
        }


        private void Button_Back_To_LogIn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow menu = new MainWindow();
            menu.Show();
            this.Close();
        }

        private void Button_Register_Click(object sender, RoutedEventArgs e)
        {

            SqlConnection sqlCon = new SqlConnection();
            sqlCon.ConnectionString = "Server=.;Database=catalog;Trusted_Connection=true";
           
            try
            {
                if (sqlCon.State == System.Data.ConnectionState.Closed)
                    sqlCon.Open();
                String query = "UPDATE Profesori SET username = @Username, password = @Password WHERE(Nume_Profesor = @Nume AND Prenume_Profesor = @Prenume)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.CommandType = System.Data.CommandType.Text;
                sqlCmd.Parameters.AddWithValue("@Username", TextBox_Username.Text);
                sqlCmd.Parameters.AddWithValue("@Password", TextBox_Parola.Text);
                sqlCmd.Parameters.AddWithValue("@Nume", TextBox_Nume.Text);
                sqlCmd.Parameters.AddWithValue("@Prenume", TextBox_Prenume.Text);

                if (TextBox_Username.Text != "" && TextBox_Parola.Text != "" && TextBox_Nume.Text != "" && TextBox_Prenume.Text != ""  && CheckExistingUsername(TextBox_Username.Text))
                {
                    int count = Convert.ToInt32(sqlCmd.ExecuteScalar()); // fara comanda asta nu face nimic
                    MessageBox.Show("V-ati inregistrat cu succes!");
                    //MainWindow dashboard = new MainWindow();
                    //dashboard.Show();
                    //this.Close();
                }
                else
                    MessageBox.Show("Inregistrarea a esuat!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }

        }
    }

}
    

