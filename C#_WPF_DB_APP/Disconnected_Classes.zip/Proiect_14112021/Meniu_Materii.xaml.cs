﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Meniu_Materii.xaml
    /// </summary>
    public partial class Meniu_Materii : Window
    {

        static string connectionString = "Server=.;Database=catalog;Trusted_Connection=true";
        SqlConnection connection = new SqlConnection(connectionString);
        DataTable DS = new DataTable();
        SqlDataAdapter DA = new SqlDataAdapter();

        public Meniu_Materii()
        {
            InitializeComponent();
            UpdateItems();
        }


        private void UpdateItems()
        {
            try
            {

                using (SqlConnection con = new SqlConnection("Server=.;Database=catalog;Trusted_Connection=true"))
                {
                    con.Open();
                    SqlDataAdapter ProjectTableTableAdapter = new SqlDataAdapter("SELECT Nume_Materie FROM Materii", con);
                    DataSet ds = new DataSet();
                    ProjectTableTableAdapter.Fill(ds, "Nume_Materie");

                    ComboBox_Materii.ItemsSource = ds.Tables["Nume_Materie"].DefaultView;
                    ComboBox_Materii.DisplayMemberPath = "Nume_Materie";
                    ComboBox_Materii.SelectedValue = "Id_Materii";

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        private void Button_Inapoi_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }

        private void ComboBox_Materii_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          


            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand selectCMD;
            selectCMD = new SqlCommand(string.Format
               ("SELECT P.Nume_Profesor + ' ' + P.Prenume_Profesor AS 'Cadre didactice' FROM Materii AS M INNER JOIN Materii_Profesori AS MP ON M.Id_Materie = MP.Id_Materie INNER JOIN Profesori AS P ON MP.Id_Profesor = P.Id_Profesor WHERE M.Nume_Materie = @Materie"),
               connection);


            selectCMD.Parameters.AddWithValue("@Materie", ComboBox_Materii.Text);
            DA.SelectCommand = selectCMD;

            connection.Open();
            DS.Clear();
            DA.Fill(DS);
            DataGrid_Profesori_Materii.ItemsSource = DS.DefaultView;


            connection.Close();
        }
    }
}
