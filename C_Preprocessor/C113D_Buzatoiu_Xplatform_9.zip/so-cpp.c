#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "HashMap.h"





int CondIfs(char* cond)
{
	int var_ret = 0;
	int q;
	int nr = 0;
	int i;
	char* pch;
	char* str = (char*)malloc(strlen(cond) + 1);
	char** matrix = (char**)malloc(sizeof(char*) * 50);
	if (matrix == NULL)
		exit(12);
	for (i = 0; i < 50; i++)
	{
		matrix[i] = (char*)malloc(50 * sizeof(char));
		if (matrix[i] == NULL)
			exit(12);
	}

	strcpy(str, cond);
	pch = strtok(str, " ");
	while (pch != NULL)
	{
		strcpy(matrix[nr], pch);
		nr++;
		pch = strtok(NULL, " ");
	}
	if (nr == 1)
	{
		if (strcmp(matrix[0], "0") == 0)
			var_ret = -1;
		else
			var_ret = 1;
	}
	else if (nr != 3)
		var_ret = -1;
	else
	{
		if (strcmp(matrix[1], "==") == 0)
		{
			if (strcmp(matrix[0], matrix[2]) == 0)
				var_ret = 1;
			else var_ret = -1;
		}

		if (strcmp(matrix[1], "<") == 0)
		{
			if (strlen(matrix[0]) < strlen(matrix[2]))
				var_ret = 1;
			else if (strlen(matrix[0]) > strlen(matrix[2]))
				var_ret = -1;
			else {
				if (strcmp(matrix[0], matrix[2]) < 0)
					var_ret = 1;
				else
					var_ret = -1;
			}
		}

		if (strcmp(matrix[1], ">") == 0)
		{
			if (strlen(matrix[0]) > strlen(matrix[2]))
				var_ret = 1;
			else if (strlen(matrix[0]) < strlen(matrix[2]))
				var_ret = -1;
			else {
				if (strcmp(matrix[0], matrix[2]) > 0)
					var_ret = 1;
				else
					var_ret = -1;
			}
		}


		if (strcmp(matrix[1], "!=") == 0)
		{
			if (strcmp(matrix[0], matrix[2]) != 0)
				var_ret = 1;
			else
				var_ret = -1;
		}

		if (strcmp(matrix[1], ">=") == 0)
		{
			if (strlen(matrix[0]) > strlen(matrix[2]))
				var_ret = 1;
			else if (strlen(matrix[0]) < strlen(matrix[2]))
				var_ret = -1;
			else {
				if (strcmp(matrix[0], matrix[2]) >= 0)
					var_ret = 1;
				else
					var_ret = -1;
			}
		}

		if (strcmp(matrix[1], "<=") == 0)
		{
			if (strlen(matrix[0]) < strlen(matrix[2]))
				var_ret = 1;
			else if (strlen(matrix[0]) > strlen(matrix[2]))
				var_ret = -1;
			else {
				if (strcmp(matrix[0], matrix[2]) <= 0)
					var_ret = 1;
				else
					var_ret = -1;
			}
		}

	}

	//el iese din functie si face free si nu dezaloca la fiecare return
	free(str);
	for (q = 0; q < 50; q++)
		free(matrix[q]);
	free(matrix);

	return var_ret;

}



/*This function free elements of directories list*/
void freeDir(char** dir, int nrOfDirectories)
{
	int i;

	for (i = 0; i < nrOfDirectories; i++)
		free(dir[i]);
	free(dir);
}

/*This function replace symbols with their mapping value from Hash*/
//This function will transform a define including more defined symblos into clear text, independent,
//using the already present symbols  in the hashmap
void replace_define(char* val, char* result, Hash h)
{
	char* token = strtok(val, " ");
	char* value;

	while (token != NULL) {
		value = getHashValue(token, h);
		if (value != NULL) /*symbol exist in map*/
			strcat(result, value);
		else
			strcat(result, token);/*symbol does not exist in map*/
		token = strtok(NULL, " ");
		if (token != NULL)
			strcat(result, " ");
	}

}
/*This function makes copy of a string*/
void copyFromString(char* dest, char* src, int lenght)
{
	memset(dest, 0, LINE_SIZE);
	memcpy(dest, src, lenght);
}
/*This function skip delimitators from begining of a line*/
char* skip(char* line, char* delim)
{
	int i;

	for (i = 0; i < strlen(line); i++) {
		if (strchr(delim, line[i]) == NULL)
			return line + i;
	}
	return  NULL;
}
/*This function take symbol and mapping from a string*/
/*argv = "VAR0=1" => symbol = "VAR0", mapp = "1" */
void get_symbol(char* symbol, char* mapp, char* argv, Hash h)
{
	char* token = strtok(argv, "=\n "); ///the name of the macro cannot contain space, so space is delimiter

	memset(symbol, 0, strlen(symbol));
	memset(mapp, 0, strlen(mapp));
	memcpy(symbol, token, strlen(token) + 1);
	token = strtok(NULL, "=\n"); // the value of the macro can contain spaces, so no space delimiter
	replace_define(token, mapp, h); // 
	if (strcmp(mapp, "\0") == 0)
		memcpy(mapp, "", 2);
}
/*This function replace all symbols of a line with their HashMap value and*/
/*return as result a new line*/
char* parse_line(char* line, Hash h)
{
	/*The function go through the line using two tokens*/
	/*(2 words in 1 iteration).*/
	char* result = (char*)calloc(LINE_SIZE, sizeof(char*));
	char* aux = (char*)calloc(ELEMENT_SIZE, sizeof(char*));
	char* newline = (char*)calloc(LINE_SIZE, sizeof(char));
	char* l = newline;
	char* s = (char*)" \t\\[]{}<>=+-*/%!&|^.,:;()\n";/*delimitators*/
	char* token;
	char* p1; /*auxiliar poiters going through the line*/
	char* p2;
	char* value;
	int size_p1, size_p2;

	if (result == NULL || aux == NULL || newline == NULL)
		exit(12);
	memcpy(newline, line, strlen(line) + 1);
	/*if there are delimitators at the begining of the line,*/
		/*they will be skipped */
	l = skip(newline, s);
	if (l == NULL) {/*The line have only delimitators*/
		strcat(result, newline);
	}
	else
	{
		/*make a copy of initial line*/
		copyFromString(aux, newline, l - newline);
		// in aux avem de la primul delimitator pana la finalul liniei
		strcat(result, aux);
		/*find first word of the line*/
		token = strtok(line, s);
		p1 = token;
		size_p1 = strlen(token);
		while (token != NULL) {
			token = strtok(NULL, s);
			p2 = token;
			if (p2 != NULL)
				size_p2 = strlen(token);
			else
				size_p2 = 0;
			if (p2 == NULL) {
				/*It is final of the line and p1 contains the last*/
									/*token(word)*/
				value = getHashValue(p1, h);
				if (value == NULL) {/*symbol is not defined*/
					strcat(result, l);
				}
				else {
					/*symbol is defined and it is replaced in line*/
					copyFromString(aux, value,
						strlen(value));
					strcat(result, aux);
					l += size_p1;
					strcat(result, l);
				}

			}
			else {/*Both tokens are in line*/
				value = getHashValue(p1, h);
				if (value == NULL) {/*symbol is not defined*/
					copyFromString(aux, l, p2 - p1);
					strcat(result, aux);
					l += (p2 - p1);
				}
				else {
					/*symbol is defined and it is replaced in line*/
					copyFromString(aux, value,
						strlen(value));
					strcat(result, aux);
					l += size_p1;
					copyFromString(aux, l,
						p2 - (p1 + size_p1));
					strcat(result, aux);
					l += (p2 - (p1 + size_p1));
				}
			}
			/*p1 becomes p2 and p2 will have the next location*/
			p1 = p2;
			size_p1 = size_p2;
		}
	}
	free(newline);
	free(aux);
	return result;
}
/*This function read lines and concat lines with escaped "\n"*/
/* in only one line.*/
char* read_lines(char* buffer, FILE* inFile)
{
	char* ret;
	char* buffer1 = (char*)calloc(LINE_SIZE, sizeof(char*));

	if (buffer1 == NULL)
		exit(12);
	while (1) {
		ret = fgets(buffer1, LINE_SIZE, inFile);
		if (ret == NULL && strlen(buffer) == 0) {
			free(buffer1);
			return NULL;
		}
		if (strcmp(buffer1, "\n") == 0)
			continue;
		if (buffer1[strlen(buffer1) - 2] == '\\') {
			buffer1[strlen(buffer1) - 2] = '\0';
			strcat(buffer, buffer1);
		}
		else {
			break;
		}
	}
	strcat(buffer, buffer1);
	free(buffer1);
	return buffer;
}
/*This function resolve "define" and "udef" directives*/
/*When it is find "define" symbol is added in Hashmap, when "undef" is find,*/
/*the symbol is removed from Hashmap*/
Hash resolve_define(char* buffer, FILE* outFile, Hash hashMap, char* symbol,
	char* mapp)
{
	char* substr;
	int error;

	substr = strstr(buffer, "define");
	if (substr != NULL) {
		substr += strlen("define");/*define was found*/ //trece la simbolul de dupa define
		substr = strtok(substr, "\n");
		get_symbol(symbol, mapp, substr, hashMap);
		/*symbol is added in HashMap*/
		error = addHashElement(symbol, mapp, &hashMap);
		if (error == 0)/*allocation failed*/
			exit(12);
	}
	substr = strstr(buffer, "undef");
	if (substr != NULL) {/*undef was found*/
		substr += strlen("undef") + 1; // trece la simbolul de dupa undef
		substr = strtok(substr, "\n");
		removeHashElement(substr, &hashMap);/*symbol is removed in HashMap*/
	}
	return hashMap;
}
/*This function verify if a file exist in directories*/
/*If the file can be open means that the file exists. The function return*/
/*position in array of director when file was found. */

int file_exist(char** directories, int nrOfDirectories)
{
	FILE* h;
	int i;

	for (i = 0; i < nrOfDirectories; i++) {
		h = fopen(directories[i], "r");
		if (h != NULL) {
			fclose(h);
			return i;
		}
	}
	return -1;
}
/*The function add headerFile name to the path */
void create_path(char* headerFile, char** directories, int nrOfDirectories)
{
	int i;
	char* aux = (char*)calloc(FILE_NAME, sizeof(char));

	if (aux == NULL)
		exit(12);
	strcat(aux, "_test/inputs/");/*current directory*/
	strcat(aux, headerFile);/*add headerFile name*/
	memcpy(directories[0], aux, strlen(aux));
	for (i = 1; i < nrOfDirectories; i++) {/*add headerFile to the rest of directories*/
		strcat(directories[i], "/");
		strcat(directories[i], headerFile);
	}

	free(aux);
}
/*This function resolve "if" directives*/
/*The function has an index "a" which save the state of program*/
/*a = 1/0 - the next line will be parsed and written*/
/*a = -1 - the next line will not be written */

int verify_ifdef(char* buffer, Hash hashMap, int a)
{
	char* ifdef_cond;
	char* ifndef_cond;
	char* parsedline;
	char* if_cond;

	if (strstr(buffer, "ifdef") != NULL) {
		ifdef_cond = (strstr(buffer, "#ifdef"));
		ifdef_cond = ifdef_cond + strlen("#ifdef") + 1;
		ifdef_cond[strlen(ifdef_cond) - 1] = '\0';
		/*verify if symbol is in HashMap*/
		if (getHashValue(ifdef_cond, hashMap) != NULL)
			a = 1;/*next line will be written*/
		else
			a = -1;/*next line will not be written*/
	}
	if (strstr(buffer, "ifndef") != NULL) {
		ifndef_cond = (strstr(buffer, "#ifndef"));
		ifndef_cond = ifndef_cond + strlen("#ifndef") + 1;
		ifndef_cond[strlen(ifndef_cond) - 1] = '\0';
		/*verify if symbol is in HashMap*/
		if (getHashValue(ifndef_cond, hashMap) == NULL)
			a = 1;/*symbol is not in HashMap*/
		else
			a = -1;/*next line will not be written*/
	}
	/*"else" directive switch the sens of index*/
	if (strstr(buffer, "#else") != NULL) {
		if (a == 1)
			a = -1;
		else
			if (a == -1)
				a = 1;
	}
	/*"endif" directive is reset*/
	//ifndef_cond = (strstr(buffer, "#ifndef"));
	if (strstr(buffer, "#endif") != NULL)
		a = 0;
	/*"if" directive is the same as "ifdef" */
	if (/*(strstr(buffer, "if") != NULL) &&
		(strncmp(buffer, "#if ", 4) == 0)*/
		strstr(buffer, "#if ") != NULL) {
		if_cond = strstr(buffer, "#if "); //buffer + strlen("#if") + 1;
		if_cond = if_cond + strlen("#if") + 1;
		if_cond[strlen(if_cond) - 1] = '\0';
		/*the line is parsed in case it has symbols*/
		parsedline = parse_line(if_cond, hashMap);
		/*if condition is != 0, the next line will be written*/
		a = CondIfs(parsedline);
		//if (strcmp(if_cond, parsedline) != 0) {
		//	if (strcmp(parsedline, "0") != 0)
		//		a = 1;/*next line will be written*/
		//	else
		//		a = -1;
		//}
		//else {
		//	if (strcmp(if_cond, "0") != 0)
		//		a = 1;/*next line will be written*/
		//	else
		//		a = -1;
		//}
		if (parsedline != NULL)
			free(parsedline);

	}
	/*"elif" directive is the same as "if"*/
	/*it is verified if previous if was executed*/
	if (strstr(buffer, "elif") != NULL && a == -1) {
		//if_cond = buffer + strlen("#elif") + 1;
		if_cond = (strstr(buffer, "#elif"));
		if_cond = if_cond + strlen("#elif") + 1;
		if_cond[strlen(if_cond) - 1] = '\0';
		parsedline = parse_line(if_cond, hashMap);
		a = CondIfs(parsedline);
		//if (strcmp(if_cond, parsedline) != 0) {
		//	if (strcmp(parsedline, "0") != 0)
		//		a = 1;/*next line will be written*/
		//	else
		//		a = -1;
		//}
		//else {
		//	if (strcmp(if_cond, "0") != 0)
		//		a = 1;/*next line will be written*/
		//	else
		//		a = -1;
		//}
		if (parsedline != NULL)
			free(parsedline);
	}
	return a;
}

/*The function remevove the last headerFile name from directories*/
void reset_directories(char** directories, int nrOfDirectories)
{
	int i;
	int j;
	int nr;
	char* aux = (char*)calloc(1, FILE_NAME);

	if (aux == NULL)
		exit(12);
	for (i = 0; i < nrOfDirectories; i++) {
		//verify if directories contain headerFile (".h" file)
		if (strstr(directories[i], ".h") != NULL) {
			nr = 0;
			memcpy(aux, directories[i], strlen(directories[i]));
			/*remove headerFile name*/
			for (j = strlen(directories[i]); j > 0; j--) {
				nr++;
				if (directories[i][j] == '/')
					break;
			}
			nr = nr - 1;
			free(directories[i]);
			directories[i] = (char*)calloc(1, 2 * FILE_NAME);
			if (directories[i] == NULL)
				exit(12);
			//add new path
			memcpy(directories[i], aux, strlen(aux) - nr);
		}
	}
	free(aux);
}
/*This function process the input file. It resolve all directives.*/
Hash process_file(FILE* inFile, FILE* outFile, char** directories,
	int nrOfDirectories, Hash hashMap)
{
	char* buffer = (char*)calloc(LINE_SIZE, sizeof(char));
	char* headerFile;
	int x;
	FILE* h;
	char* symbol = (char*)calloc(ELEMENT_SIZE, sizeof(char));
	char* mapp = (char*)calloc(ELEMENT_SIZE, sizeof(char));
	char* parsedline;
	int condition = 0;

	if (buffer == NULL || symbol == NULL || mapp == NULL)
		exit(12);
	while (read_lines(buffer, inFile) != NULL) {
		if (strchr(buffer, '#') != NULL/*buffer[0] == '#'*/) {

			//facem strchr pentru ca #ifdef...etc nu trebuie sa fie la inceput de rand

			/*verify if the line start with "#" for directives */
			if (strstr(buffer, "include") != NULL) {
				/*extract headerFile name*/
				headerFile = strstr(buffer, "\""); // don't care about #include<smth>, only about #include"smth.h"
				headerFile = headerFile + 1;
				headerFile[strlen(headerFile) - 2] = '\0';
				/*remove last headerFile from directoties*/
				reset_directories(directories, nrOfDirectories);
				/*create the new path to headerFile*/
				create_path(headerFile, directories, nrOfDirectories);
				/*verify if headerFile file exist*/
				x = file_exist(directories, nrOfDirectories);
				if (x == -1)
					exit(12);
				else {
					h = fopen(directories[x], "r");
					if (h == NULL) {
						fclose(h);
						exit(12);
					}
					else {
						hashMap = process_file(h,
							outFile, directories,
							nrOfDirectories, hashMap);
						fclose(h);
					}
				}

			}
			/*resolve "define" directives*/
			if (strstr(buffer, "define") != NULL)
				if (condition == 1 || condition == 0)
					hashMap = resolve_define(buffer,
						outFile, hashMap, symbol,
						mapp);
			/*resolve "undef" directives*/
			if (strstr(buffer, "undef") != NULL)
				if (condition == 1 || condition == 0)
					hashMap = resolve_define(buffer,
						outFile, hashMap,
						symbol, mapp);
			condition = verify_ifdef(buffer, hashMap, condition);
			//aici problema ca se poate ca #ifdef sa aiba alineat!!

		}

		else {/*the line will be parsed only if the index is 0 or 1*/
		 /*(if/ifdef/undef block is true or the "else"*/
		 /* block is executed)*/
			//condition = verify_ifdef(buffer, hashMap, condition);
			if (condition == 1 || condition == 0) {
				parsedline = parse_line(buffer, hashMap);
				fprintf(outFile, "%s", parsedline);
				free(parsedline);
			}
		}
		memset(buffer, 0, LINE_SIZE);
	}
	free(buffer);
	free(symbol);
	free(mapp);
	return hashMap;
}

int main(int argc, char* argv[])
{
	int have_input = 0;
	int i = 0;
	int error;
	int in = 1, out = 1;
	int err = 0;
	FILE* inFile = NULL;
	FILE* outFile = NULL;
	char* inName;
	char* outName;
	Hash hashMap = NULL;
	char* symbol = (char*)calloc(ELEMENT_SIZE, sizeof(char));
	char* mapp = (char*)calloc(ELEMENT_SIZE, sizeof(char));
	char* buffer = (char*)calloc(3 * LINE_SIZE, sizeof(char));
	int nrOfDirectories = 1;
	char** directories = (char**)calloc(nrOfDirectories, sizeof(char*));

	directories[0] = (char*)calloc(PATH_SIZE, sizeof(char));
	if (directories[0] == NULL)
		exit(12);
	memcpy(directories[0], ".\0", 2);

	if ((symbol == NULL) || (mapp == NULL) || (buffer == NULL) ||
		(directories == NULL))
		exit(12);
	inName = (char*)calloc(FILE_NAME, sizeof(char));
	outName = (char*)calloc(FILE_NAME, sizeof(char));
	if ((inName == NULL) || (outName == NULL))
		exit(12);
	/*no arguments*/
	if (argc == 1) {
		inFile = stdin;
		outFile = stdout;
	}
	else {
		for (i = 1; i < argc; i++) {

			in = 1;
			/*resolve -D parameters*/
			if (strncmp(argv[i], "-D", strlen("-D")) == 0) {
				in = 0;
				/*extract symbol and mapping*/
				if (strlen(argv[i]) > 2) {
					memmove(argv[i], argv[i] + 2,
						strlen(argv[i]));
					get_symbol(symbol, mapp, argv[i],
						hashMap);
				}
				else {
					get_symbol(symbol, mapp, argv[i + 1],
						hashMap);
					i++;
				}
				/*add in HashMap*/
				if (hashMap == NULL) {
					hashMap = createHashElement(symbol, mapp);
					if (!hashMap)
						exit(12);
				}
				else {
					error = addHashElement(symbol, mapp, &hashMap);
					if (error == 0)
						exit(12);
				}
			}
			/*resolve -o parameters and open the output file*/
			if (strncmp(argv[i], "-o", strlen("-o")) == 0) {
				in = 0;
				out = 0;
				if (strlen(argv[i]) > 2) {
					memmove(argv[i], argv[i] + 2,
						strlen(argv[i]));
					outFile = fopen(argv[i + 1], "w");
				}
				else {
					outFile = fopen(argv[i + 1], "w");
					i++;
				}
			}
			///*resolve -I parameter and adding path to directories*/
			if (strncmp(argv[i], "-I", strlen("-I")) == 0) {
				in = 0;
				if (strlen(argv[i]) > 2) {
				}
				else {
					i++;
					nrOfDirectories += 1;
					/*realloc dimensions for directories*/
					/* and add a new path*/
					directories = (char**)realloc(directories,
						nrOfDirectories * sizeof(char*));
					if (directories == NULL)
						exit(12);
					directories[nrOfDirectories - 1] = (char*)
						calloc(PATH_SIZE, strlen(argv[i]));
					if (directories[nrOfDirectories - 1] == NULL)
						exit(12);
					memcpy(directories[nrOfDirectories - 1],
						argv[i], strlen(argv[i]));
				}
			}
			/*verify if argv does not contain "-o", "-D" or "-I"*/
			if (in) {
				err++;
				if (err == 1) {
					inFile = fopen(argv[i], "r");

					have_input = 1;
					if (inFile == NULL)
						exit(1);
				}
			}
		}
		/*verify if there are 3 argumets without "-o",*/
		/*"-D" or "-I" and set */
		/*input and output file*/
		if ((argc == 3) && (in == 1) && (out == 1) && (err == 2)) {
			if (inFile == NULL) {
				inFile = fopen(argv[1], "r");
				if (inFile == NULL)
					exit(1);
			}
			outFile = fopen(argv[2], "w");
			if (outFile == NULL)
				exit(1);
		}
		else {
			/*The program exit if there are more than 3 arguments*/
					/* without "-o", "-D" or "-I"*/
			if (err == 3)
				exit(1);
			//set input and output file to stdin and stdout
			if (out == 1)
			{
				outFile = stdout;

			}
			if (have_input == 0)
			{
				inFile = stdin;

			}
		}
	}



	hashMap = process_file(inFile, outFile, directories,
		nrOfDirectories, hashMap);

	freeHashMap(&hashMap);
	free(symbol);
	free(mapp);
	free(buffer);
	free(inName);
	free(outName);
	freeDir(directories, nrOfDirectories);
	fclose(outFile);
	fclose(inFile);

	return 0;
}

