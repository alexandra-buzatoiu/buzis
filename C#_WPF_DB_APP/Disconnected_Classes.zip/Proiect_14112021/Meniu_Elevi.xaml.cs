﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Meniu_Elevi.xaml
    /// </summary>
    public partial class Meniu_Elevi : Window
    {
        static string connectionString = "Server=.;Database=catalog;Trusted_Connection=true";
        SqlConnection connection = new SqlConnection(connectionString);
        DataTable DS = new DataTable();
        SqlDataAdapter DA = new SqlDataAdapter();

        string currentTableName = "";

        public Meniu_Elevi()
        {
            InitializeComponent();
            UpdateItems();
        }

        private void Button_Inapoi_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }


        private void UpdateItems()
        {
            try
            {
                
                using (SqlConnection con = new SqlConnection("Server=.;Database=catalog;Trusted_Connection=true"))
                {
                    con.Open();
                    SqlDataAdapter ProjectTableTableAdapter = new SqlDataAdapter("SELECT Nume_Materie FROM Materii", con);
                    DataSet ds = new DataSet();
                    ProjectTableTableAdapter.Fill(ds, "Nume_Materie");

                    ComboBox_Materii.ItemsSource = ds.Tables["Nume_Materie"].DefaultView;
                    ComboBox_Materii.DisplayMemberPath = "Nume_Materie";
                    ComboBox_Materii.SelectedValue = "Id_Materii";
                    
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        private void ComboBox_Materii_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


            // UpdateItems(); nu punem asta aici ca nu salveaza ce selectez
            // ComboBox_Materii.SelectedIndex = 1;
            //var result = ComboBox_Materii.Text;
            //MessageBox.Show(result);

            var selected = this.ComboBox_Materii.SelectionBoxItemStringFormat;
            



        }

        private void Buton_Generare_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand selectCMD;
            //SqlDataAdapter DA = new SqlDataAdapter();

            selectCMD = new SqlCommand(string.Format
                 ("Select M.Nume_Materie, C.Nota, C.Data FROM Catalog_Note AS C INNER JOIN Elevi AS E ON C.Id_Elev = E.Id_Elev INNER JOIN Materii AS M ON M.Id_Materie = C.Id_Materie WHERE E.Nume_Elev = @Nume AND E.Prenume_Elev = @Prenume AND M.Nume_Materie = @Materie"),
                 connection);

            selectCMD.Parameters.AddWithValue("@Nume", TextBox_NumeElev.Text);
            selectCMD.Parameters.AddWithValue("@Prenume", TextBox_PrenumeElev.Text);
            selectCMD.Parameters.AddWithValue("@Materie", ComboBox_Materii.Text);
            DA.SelectCommand = selectCMD;

            connection.Open();
            DS.Clear();
            DA.Fill(DS);
            DataGrid_SituatieElev.ItemsSource = DS.DefaultView;


            connection.Close();
        }
    }
}
