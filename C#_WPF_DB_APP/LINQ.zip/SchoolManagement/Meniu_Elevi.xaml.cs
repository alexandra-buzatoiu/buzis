﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Meniu_Elevi.xaml
    /// </summary>
    public partial class Meniu_Elevi : Window
    {
        catalogDataContext cd = new catalogDataContext();


        public Meniu_Elevi()
        {
            InitializeComponent();
            UpdateItems();
        }

        private void Button_Inapoi_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }


        private void UpdateItems()
        {
            try
            {
                
               
                    var result = (from t in cd.Materiis
                                 select t.Nume_Materie).ToList();
 
                    ComboBox_Materii.ItemsSource = result;
 

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        private void ComboBox_Materii_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


            var selected = this.ComboBox_Materii.SelectionBoxItemStringFormat;
           

        }

        private void Buton_Generare_Click(object sender, RoutedEventArgs e)
        {
            
            string nume = TextBox_NumeElev.Text;
            string prenume = TextBox_PrenumeElev.Text;
            string materie = ComboBox_Materii.Text;
            var result = (from c in cd.Catalog_Notes
                         join el in cd.Elevis
                         on c.Id_Elev equals el.Id_Elev
                         join m in cd.Materiis
                         on c.Id_Materie equals m.Id_Materie
                         where el.Nume_Elev == nume && el.Prenume_Elev == prenume && m.Nume_Materie == materie
                         select new { m.Nume_Materie, c.Data, c.Nota }).ToList();
            DataGrid_SituatieElev.ItemsSource = result;

        }
    }
}
