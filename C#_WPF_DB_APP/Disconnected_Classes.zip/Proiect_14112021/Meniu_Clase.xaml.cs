﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Proiect_14112021
{
    /// <summary>
    /// Interaction logic for Meniu_Clase.xaml
    /// </summary>
    public partial class Meniu_Clase : Window
    {
        static string connectionString = "Server=.;Database=catalog;Trusted_Connection=true";
        SqlConnection connection = new SqlConnection(connectionString);
        DataTable DS = new DataTable();
        SqlDataAdapter DA = new SqlDataAdapter();


        public Meniu_Clase()
        {
            InitializeComponent();
            ComboBox_Detalii_Clasa.Items.Clear();
            ComboBox_Detalii_Clasa.Items.Add("Componenta clasa");
            ComboBox_Detalii_Clasa.Items.Add("Incadrare clasa");
            UpdateItems();

        }


        private void UpdateItems()
        {
            try
            {
                
                using (SqlConnection con = new SqlConnection("Server=.;Database=catalog;Trusted_Connection=true"))
                {
                    con.Open();
                    SqlDataAdapter ProjectTableTableAdapter = new SqlDataAdapter("SELECT Nume_Clasa FROM Clase", con);
                    DataSet ds = new DataSet();
                    ProjectTableTableAdapter.Fill(ds, "Nume_Clasa");

                    ComboBox_Clasa.ItemsSource = ds.Tables["Nume_Clasa"].DefaultView;
                    ComboBox_Clasa.DisplayMemberPath = "Nume_Clasa";
                    ComboBox_Clasa.SelectedValue = "Id_Clasa";

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Button_Inapoi_Click(object sender, RoutedEventArgs e)
        {
            Possible_Actions ob = new Possible_Actions();
            ob.Show();
            this.Close();
        }

        private void DataGrid_Clasa_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ComboBox_Clasa_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

      

        private void Button_Generare_Click(object sender, RoutedEventArgs e)
        {
            
            if (ComboBox_Detalii_Clasa.Text == "Componenta clasa")
            {
                SqlCommand selectCMD;
                selectCMD = new SqlCommand(string.Format
                   ("SELECT E.Nume_Elev, E.Prenume_Elev from  Clase AS C INNER JOIN Elevi AS E ON C.Id_Clasa = E.Id_Clasa WHERE C.Nume_Clasa = @Clasa"),
                   connection);


                selectCMD.Parameters.AddWithValue("@Clasa", ComboBox_Clasa.Text);
                DA.SelectCommand = selectCMD;

                connection.Open();
                DS.Clear();
                DA.Fill(DS);
                DataGrid_Clasa.ItemsSource = DS.DefaultView;


                connection.Close();
            }

            else
            {
                SqlCommand selectCMD;
                selectCMD = new SqlCommand(string.Format
                   ("SELECT M.Nume_Materie, P.Nume_Profesor + ' ' + P.Prenume_Profesor AS 'Profesor' FROM Clase AS C INNER JOIN Repartitie_Profesori_Clase_Materii AS RPCM ON C.Id_Clasa = RPCM.Id_Clasa INNER JOIN Profesori AS P ON P.Id_Profesor = RPCM.Id_Profesor INNER JOIN Materii AS M ON RPCM.Id_Materie = M.Id_Materie WHERE C.Nume_Clasa = @Clasa"),
                   connection);


                selectCMD.Parameters.AddWithValue("@Clasa", ComboBox_Clasa.Text);
                DA.SelectCommand = selectCMD;

                connection.Open();
                DS.Clear();
                DA.Fill(DS);
                DataGrid_Clasa.ItemsSource = DS.DefaultView;


                connection.Close();
            }


        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
    
}
